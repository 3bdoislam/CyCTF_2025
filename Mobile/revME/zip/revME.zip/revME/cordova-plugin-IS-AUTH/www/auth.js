var exec = require('cordova/exec');

function auth() {
  this.name = 'auth';
}

auth.prototype.func01 = function (successCallback, errorCallback) {
  exec(successCallback, errorCallback, this.name, 'func01', []);
};

module.exports = new auth();
