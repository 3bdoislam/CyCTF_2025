#import "Cordova/CDV.h"
#import "Cordova/CDVViewController.h"
#import "auth.h"

@implementation auth

- (void) func01:(CDVInvokedUrlCommand*)command;
{
    CDVPluginResult *pluginResult;

    @try
    {
        bool jailbroken = [self func02];
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsBool:jailbroken];
        if(jailbroken)
        {
            int *invalidPointer = NULL;
            *invalidPointer = 10;
        }
    }
    @catch (NSException *exception)
    {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:exception.reason];
    }
    @finally
    {
        [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }
}

- (bool) func02 {
    return YES;
}

@end
